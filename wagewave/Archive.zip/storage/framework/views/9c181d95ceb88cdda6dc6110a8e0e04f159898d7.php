<h6><?php echo e($timesheet->job->job); ?></h6>
<p><strong>Time In: </strong><?php echo e($timesheet->clock_in); ?></p>
<p><strong>Time Out: </strong><?php echo e($timesheet->clock_out); ?></p>