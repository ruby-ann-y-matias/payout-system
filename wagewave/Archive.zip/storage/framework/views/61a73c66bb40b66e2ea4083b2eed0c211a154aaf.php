<?php $__env->startSection('breadcrumb'); ?>
    <nav>
        <div class="nav-wrapper indigo darken-2">
            <a id="rootCrumb" class="breadcrumb" href="<?php echo e(url('/home')); ?>">Index</a>
            <a class="breadcrumb" href="<?php echo e(url('/payout')); ?>">Payout</a>
        </div>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">
		
		<?php if(!$payout->isEmpty()): ?>

			<a class="dropdown-trigger btn-large teal log-actions" href="#dropdownSort"><i class="material-icons">sort</i> Sort Payout <?php echo e($criteria); ?></a>

			<h4 class="paid-total-info right"><small>Total Paid Wages:</small> $<?php echo e($paid_total); ?></h4>

			<ul id="dropdownSort" class="dropdown-content">
				<li>
					<a href="<?php echo e(url('/payout/sort-by-priority')); ?>">Sort by Priority <i class="material-icons">priority_high</i></a>
				</li>
				<li>
					<a href="<?php echo e(url('/payout/sort-by-name')); ?>">Sort by Name <i class="material-icons">person</i></a>
				</li>
				<li>
					<a href="<?php echo e(url('/payout/sort-by-job')); ?>">Sort by Job <i class="material-icons">build</i></a>
				</li>
				<li>
				<a href="<?php echo e(url('/payout/sort-by-date')); ?>">Sort by Date <i class="material-icons">date_range</i></a>
				</li>
				<li>
				<a href="<?php echo e(url('/payout/sort-by-hours')); ?>">Sort by Hours <i class="material-icons">timer</i></a>
				</li>
				<li>
				<a href="<?php echo e(url('/payout/sort-by-wage')); ?>">Sort by Wage <i class="material-icons">payment</i></a>
				</li>
			</ul>

			<table id="logsTable" class="responsive-table centered striped highlight">
				<thead>
					<th>Name</th>
					<th>Job</th>
					<th>Date</th>
					<th>Hours</th>
					<th>Wage</th>
					<th>Status</th>
				</thead>
				<tbody>
				<?php $__currentLoopData = $payout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($wage->name); ?></td>
						<td><?php echo e($wage->job); ?></td>
						<td ><?php echo e($wage->date); ?></td>
						<td><?php echo e($wage->hours); ?></td>
						<td><strong>USD</strong> <?php echo e($wage->wage); ?></td>
						<?php if($wage->status == 'pending'): ?>
						<td><button class="btn teal modal-trigger pay-now-btn" href="#payoutModal" value="<?php echo e($wage->timesheet_id); ?>">Pay Now</button></td>
						<?php else: ?>
						<td><?php echo e($wage->status); ?></td>
						<?php endif; ?>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<div class="modal" id="payoutModal">
				<div id="payoutModalContent" class="modal-content">
					
				</div>
				<div class="modal-footer">
					<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
				</div>
			</div>

		<?php else: ?>

		<div class="empty-container">
			<h5 class="empty-msg center-align indigo-text">No payout found.</h5>
		</div>

		<?php endif; ?>

	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('indiv_js'); ?>
	<script type="text/javascript">

		$(document).ready(function() {
			$('.modal').modal();
			$('.dropdown-trigger').dropdown();
		});

		$('.pay-now-btn').on('click', function() {
			var logID = $(this).val();
			var csrf = $('[name="csrf-token"]').attr('content');
			// console.log(csrf);
			// console.log(wageID);
			$.post('/confirm-sorted-payout/',
				{
					timesheet_id: logID,
					_token: csrf
				},
				function(data, status) {
					$('#payoutModalContent').html(data);
				});
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>