

<h5 id="confirmPayoutTitle" class="indigo-text">Confirm Payout</h5>
<form method="POST" id="payment-form"  action=<?php echo e(url('payout/update-status')); ?>>
	<?php echo e(csrf_field()); ?>

	<div class="row">
		<div class="input-field col s12">
			<input hidden name="payout_id" value="<?php echo e($payout->id); ?>">
			<input type="text" id="amountInput" name="amount" value="$ <?php echo e($payout->wage); ?>" readonly>
			<label id="amountLabel" class="active teal-text" for="amount">Amount to Pay:</label>
		</div>     
		<div id="payout-actions" class="center">
			<button type="submit" class="btn payout-option">Mark as Released</button>
		</div>
	</div>
</form>
