<?php $__env->startSection('breadcrumb'); ?>
    <nav>
        <div class="nav-wrapper indigo darken-2">
            <a id="rootCrumb" class="breadcrumb" href="<?php echo e(url('/home')); ?>">Index</a>
            <a class="breadcrumb" href="<?php echo e(url('/settings')); ?>">Settings</a>
        </div>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">
		
		<div class="row">
			<div class="col s12">
				<div class="card">
					<div class="card-content">
						<div id="dashTitle" class="card-title indigo-text">Settings</div>
						<div class="switch">
							<label>
								<span id="themeSwitchLabel">Dark Mode</span>
								<input type="checkbox" id="theme" value="on">
								<span class="lever"></span>
							</label>
						</div>
					</div>
				</div>
			</div>
		</div>
		
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('indiv_js'); ?>
	<script type="text/javascript">

		$(document).ready(function() {
			$('#theme').on('change', function() {
				var x = $('#theme').val();
				alert(x);
			});
		});

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>