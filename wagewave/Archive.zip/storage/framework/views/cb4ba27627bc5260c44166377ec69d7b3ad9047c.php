<?php $__env->startSection('content'); ?>
	<div id="jobDonutDiv">
    </div>
    <?= Lava::render('DonutChart', 'JobDonut', 'jobDonutDiv'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>