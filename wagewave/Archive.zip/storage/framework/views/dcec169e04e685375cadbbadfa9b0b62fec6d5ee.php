<div class="row">
	<form action=<?php echo e(url('/timesheet/late-log-out')); ?> method="POST">
		<?php echo e(csrf_field()); ?>

		<div class="input-field col s12 grey lighten-3">
			<input type="text" id="name" value="<?php echo e($timesheet->employee->name); ?>" readonly>
			<label class="active teal-text" for="name">Employee Name:</label>
		</div>
		<div class="input-field col s12 grey lighten-3">
			<input type="text" id="job" value="<?php echo e($timesheet->job->job); ?>" readonly>
			<label class="active teal-text" for="job">Job Title:</label>
		</div>
		<div class="input-field col s12 grey lighten-3">
			<input type="time" id="clock_in" value="<?php echo e($timesheet->clock_in); ?>" readonly>
			<label class="active teal-text" for="clock_in">Time In:</label>
		</div>

		<div class="input-field col s12">
			<select id="dateOut" name="date_out" required>
				<option selected><?php echo e($timesheet->date); ?></option>
				<option><?php echo e($max_date); ?></option>
			</select>
			<label class="teal-text">Date of Clock Out:</label>
		</div>
		<div class="input-field col s12">
			<input type="time" id="clock_out" name="clock_out" value="<?php echo e($timesheet->clock_out); ?>" min="<?php echo e($min_time); ?>" required>
			<label class="active teal-text" for="clock_out">Time Out:</label>
		</div>
		
		<meta name="start_date" content="<?php echo e($timesheet->date); ?>">
		<meta name="start_time" content="<?php echo e($timesheet->clock_in); ?>">
		<input hidden type="number" name="timesheet_id" value="<?php echo e($timesheet->id); ?>">
		<button type="submit" id="lateLogOutBtn" class="waves-effect btn teal right" type="submit">Clock Out</button>
	</form>
</div>

<script type="text/javascript">
	$(document).ready(function() {
		$('select').formSelect();
	});

	$('#dateOut').on('change', function() {
		var startDate = $('[name="start_date"]').attr('content');
		var startTime = $('[name="start_time"]').attr('content');
		var selectedDate = $('#dateOut').val();
		// alert(startDate);
		// alert(startTime);
		if (startDate != selectedDate) {
			$('#clock_out').removeAttr('min');
			$('#clock_out').attr('max', startTime);
		}
	});
</script>