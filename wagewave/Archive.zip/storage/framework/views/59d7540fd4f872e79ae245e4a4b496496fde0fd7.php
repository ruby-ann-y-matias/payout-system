<h6 class="job-title"><?php echo e($timesheet->job->job); ?></h6>
<p><small class="indigo-text">Hourly Rate: USD <?php echo e($timesheet->job->hourly_rate); ?></small></p>
<p><strong>Time In: </strong><?php echo e($timesheet->clock_in); ?></p>
<p><strong>Time Out: </strong><?php echo e($timesheet->clock_out); ?></p>
<hr>
<p><strong>Hours Worked: </strong><?php echo e(number_format($payout->hours, 2, '.', ',')); ?> ( <?php echo e(number_format($minutes, 2, '.', ',')); ?> minutes )</p>
<p><strong>Wage Earned: USD </strong><?php echo e(number_format($payout->wage, 2, '.', ',')); ?></p>
