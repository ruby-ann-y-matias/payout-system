<?php $__env->startSection('breadcrumb'); ?>
    <nav>
        <div class="nav-wrapper indigo darken-2">
            <a id="rootCrumb" class="breadcrumb" href="<?php echo e(url('/home')); ?>">Index</a>
            <a class="breadcrumb" href="<?php echo e(url('/jobs')); ?>">Jobs</a>
        </div>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">
		<?php if(!$jobs->isEmpty()): ?>
		<input type="text" id="searchInput" onkeyup="pseudoFuzzy()" placeholder="Search for job title" class="form-control">

		<ul id="jobList">
			<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><a href=<?php echo e(url("job/$job->id")); ?> class="black-text"><?php echo e($job->job); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<li><a href="#"> <a></li>
		</ul>

		

		<div class="fixed-action-btn">
			<a class="btn-floating btn-large teal modal-trigger" href="<?php echo e(url('/jobs/add-new')); ?>">
				<i class="material-icons">add</i>
			</a>
		</div>

		<?php else: ?>

		<div class="empty-container">
			<h5 class="empty-msg center-align indigo-text">Job list feels quite lonely.</h5>
			<a class="btn-large teal modal-trigger" href="<?php echo e(url('/jobs/add-new')); ?>">Add New Job Now</a>
		</div>

		<?php endif; ?>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('indiv_js'); ?>
	<script type="text/javascript">
		
		function pseudoFuzzy() {
			var input, filter, ul, li, a, i;
			input = document.getElementById("searchInput");
			filter = input.value.toUpperCase();
			// alert(filter);
			ul = document.getElementById("jobList");
			li = ul.getElementsByTagName("li");

			// console.log(JSON.parse(JSON.stringify(li)));
			// console.log(li.length);

			for (i = 0; i < li.length; i++) {
				a = li[i].getElementsByTagName("a")[0];
				// console.log(a.innerHTML);
				if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
					li[i].style.display = "";
				} else {
					li[i].style.display = "none";
				}
			}
		}

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>