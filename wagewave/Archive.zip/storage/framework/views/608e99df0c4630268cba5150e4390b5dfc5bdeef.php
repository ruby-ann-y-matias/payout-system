<?php $__env->startSection('breadcrumb'); ?>
    <nav>
        <div class="nav-wrapper indigo darken-2">
            <a id="rootCrumb" class="breadcrumb" href="<?php echo e(url('/home')); ?>">Index</a>
            <a class="breadcrumb" href="<?php echo e(url('/employees')); ?>">Employees</a>
            <a class="breadcrumb" href=<?php echo e(url("/employee/$employee->id")); ?>><?php echo e($employee->id); ?></a>
        </div>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col s12 m6 l4">
				<div class="card employee-card">
					<div class="card-image halfway-fab-header">
						<button id="editBtn" class="btn-floating halfway-fab waves-effect waves-light red darken-4"><i class="material-icons">edit</i></button>
					</div>
					<div id="currentInfo" class="card-content">
						<h5><?php echo e($employee->name); ?></h5>
						<p><strong>Contact no.:</strong> <?php echo e($employee->mobile); ?></p>
						<hr>
						<p><strong>Address:</strong> <?php echo e($employee->address); ?></p>
						<hr>
						<p><strong>Birth date:</strong> <?php echo e($employee->birth_date); ?></p>
						<hr>
						<p><strong>TIN:</strong> <?php echo e($employee->TIN); ?></p>
						<hr>
						<p><strong>SSS:</strong> <?php echo e($employee->SSS); ?></p>
						<hr>
						<p><strong>Pag-ibig MID:</strong> <?php echo e($employee->Pagibig); ?></p>
						<button type="button" class="btn waves-effect red darken-4 modal-trigger delete-btn" href="#deleteEmpModal"><i class="material-icons">delete_forever</i> Delete Account</button>
						<div class="modal" id="deleteEmpModal">
							<div id="deleteModalContent" class="modal-content">
								<form action="/employee/delete/<?php echo e($employee->id); ?>" method="POST">
									<?php echo e(csrf_field()); ?>

									<?php echo e(method_field('delete')); ?>

									<p>Are your sure you want to delete<br><?php echo e($employee->name); ?>'s account?</p>
									<input hidden name="employee_id" value="<?php echo e($employee->id); ?>">
									<button type="submit" class="btn waves-effect red darken-4">Yes</button>
									<button type="button" class="btn waves-effect teal lighten-3 modal-close">No</button>
								</form>
							</div>
							<div class="modal-footer">
								<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
							</div>
						</div>
					</div>
					<div id="editInfo" class="card-content" hidden>
						<form id="editForm" action=<?php echo e(url("/employee/$employee->id/update")); ?> method="POST">
							<?php echo e(csrf_field()); ?>

							<div class="row">
								<div class="input-field col s12">
									<input type="text" id="name" name="name" value="<?php echo e($employee->name); ?>" class="validate">
									<label class="active" for="name">Name:</label>
								</div>
								<div class="input-field col s12">
									<input type="tel" id="mobile" name="mobile" value="<?php echo e($employee->mobile); ?>" class="validate">
									<label class="active" for="mobile">Contact no.:</label>
								</div>
								<div class="input-field col s12">
									<input type="text" id="address" name="address" value="<?php echo e($employee->address); ?>" class="validate">
									<label class="active" for="address">Address:</label>
								</div>
								<div class="input-field col s12">
									<input type="date" id="birthDate" name="birth_date" value="<?php echo e($employee->birth_date); ?>" class="validate" min="2000-06-12" max="1958-06-12">
									<label class="active" for="birthDate">Birth Date:</label>
								</div>
								<div class="input-field col s12">
									<input type="text" id="TIN" name="TIN" value="<?php echo e($employee->TIN); ?>" class="validate" oninput="formatTIN()" pattern="[0-9-]{12,}" maxlength="15">
									<label class="active" for="TIN">TIN:</label>
								</div>
								<div class="input-field col s12">
									<input type="text" id="SSS" name="SSS" value="<?php echo e($employee->SSS); ?>" class="validate" oninput="formatSSS()" pattern="[0-9-]{10,}" maxlength="12">
									<label class="active" for="SSS">SSS:</label>
								</div>
								<div class="input-field col s12">
									<input type="text" id="Pagibig" name="Pagibig" value="<?php echo e($employee->Pagibig); ?>" class="validate" oninput="formatPagibig()" pattern="[0-9-]{12,}" maxlength="14">
									<label class="active" for="Pagibig">Pag-ibig MID:</label>
								</div>
								<button type="submit" class="waves-effect btn green accent-5 right">Save</button>
							</div>
						</form>
					</div>
				</div>
			</div>

			<div class="col s12 m6 l4">
				<div class="card employee-card">
					<div class="card-content">
						<h5><?php echo e($today); ?></h5>
					</div>
					<div class="card-action">

					
					<?php if(!$logs->isEmpty()): ?>
						<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							
							<?php if($timesheet->clock_out == null): ?>
							
							<div class="clock-out">
								<button class="btn teal" id="clockOut" value="<?php echo e($employee->id); ?>"><i class="material-icons">timer</i> Clock Out</button>
							</div>
							<div class="todays-log">
								<h6 class="job-title"><?php echo e($timesheet->job->job); ?></h6>
								<p><small class="indigo-text">Hourly Rate: USD <?php echo e($timesheet->job->hourly_rate); ?></small></p>
								<p><strong>Time In: </strong><?php echo e($timesheet->clock_in); ?></p>
								<p><strong>Time Out: </strong><?php echo e($timesheet->clock_out); ?></p>
							</div>

							<div class="row">
								<div class="col s12">
									<button type="button" class="btn waves-effect red darken-4 modal-trigger delete-btn" href="#deleteLogModal"><i class="material-icons">delete_forever</i> Delete Log</button>
									<div class="modal" id="deleteLogModal">
										<div id="deleteModalContent" class="modal-content">
											<form action="/timesheet/delete/<?php echo e($timesheet->id); ?>" method="POST">
												<?php echo e(csrf_field()); ?>

												<?php echo e(method_field('delete')); ?>

												<p>Are your sure you want to delete this log?</p>
												<p><small><span class="orange-text">Warning:</span> Related payout, if there's any, will be deleted, too.</small></p>
												<input hidden name="timesheet_id" value="<?php echo e($timesheet->id); ?>">
												<button type="submit" class="btn waves-effect red darken-4">Yes</button>
												<button type="button" class="btn waves-effect teal lighten-3 modal-close">No</button>
											</form>
										</div>
										<div class="modal-footer">
											<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
										</div>
									</div>
								</div>
							</div>

							<?php else: ?>

							
							<div class="todays-log">

								<h6 class="job-title"><?php echo e($timesheet->job->job); ?></h6>
								<p><small class="indigo-text">Hourly Rate: USD <?php echo e($timesheet->job->hourly_rate); ?></small></p>
								<p><strong>Time In: </strong><?php echo e($timesheet->clock_in); ?></p>
								<p><strong>Time Out: </strong><?php echo e($timesheet->clock_out); ?></p>

								<div class="row">
									<div class="col s12">
										<button type="button" class="btn waves-effect red darken-4 modal-trigger delete-btn" href="#deleteLogModal"><i class="material-icons">delete_forever</i> Delete Log</button>
										<div class="modal" id="deleteLogModal">
											<div id="deleteModalContent" class="modal-content">
												<form action="/timesheet/delete/<?php echo e($timesheet->id); ?>" method="POST">
													<?php echo e(csrf_field()); ?>

													<?php echo e(method_field('delete')); ?>

													<p>Are your sure you want to delete this log?</p>
													<p><small><span class="orange-text">Warning:</span> Related payout, if there's any, will be deleted, too.</small></p>
													<input hidden name="timesheet_id" value="<?php echo e($timesheet->id); ?>">
													<button type="submit" class="btn waves-effect red darken-4">Yes</button>
													<button type="button" class="btn waves-effect teal lighten-3 modal-close">No</button>
												</form>
											</div>
											<div class="modal-footer">
												<a href="#!" class="modal-close waves-effect waves-green btn-flat">Cancel</a>
											</div>
										</div>
									</div>
								</div>

								<?php if(!$payouts->isEmpty()): ?>

									<?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<p><strong>Hours Worked: </strong><?php echo e(number_format($payout->hours, 2, '.', ',')); ?></p>
									<p><strong>Wage Earned: USD </strong><?php echo e(number_format($payout->wage, 2, '.', ',')); ?></p>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<?php endif; ?>

							</div> 

							<?php endif; ?>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<?php else: ?>

					
						<div class="clock-in">
							<div class="row">
								<div class="input-field col s12">
									<select id="todaysJob" name="job_id" required class="validate">
										<option value="" disabled selected>Select the job</option>
										<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($job->id); ?>"><?php echo e($job->job); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<label>Today's Job</label>
								</div>
							<button class="btn teal" id="clockIn" value="<?php echo e($employee->id); ?>">Clock In</button>
							</div>
						</div>
						<div class="clock-out" hidden>
							<button class="btn teal" id="clockOut" value="<?php echo e($employee->id); ?>"><i class="material-icons">timer</i> Clock Out</button>
						</div>
						<div class="todays-log" hidden>
							
						</div>

					<?php endif; ?>
	
					</div>

				</div>
			</div>

			<div class="col s12 m6 l4">
				<div class="card employee-card hide-on-med-and-down">
					<div class="card-image">
						<img src=<?php echo e(asset("$employee->image")); ?>>
					</div>
				</div>
			</div>

			<div class="col s12">
				<div class="card">
					<div class="card-content">
						<table id="logsTable" class="responsive-table centered striped highlight">
							<h6 class="flow-text indigo-text history-owner"><?php echo e($employee->name); ?></h6>
							<thead>
								<th>Job</th>
								<th>Date</th>
								<th>Clock In</th>
								<th>Clock Out</th>
							</thead>
							<tbody>

							<?php if(!$history->isEmpty()): ?>
								<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $past): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($past->job->job); ?></td>
									<td ><?php echo e($past->date); ?></td>
									<td><?php echo e($past->clock_in); ?></td>
									<td><?php echo e($past->clock_out); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<tr>
									<td class="info-text">No past logs.</td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
								</tr>
							<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>

			<div class="col s12">
				<div class="card">
					<div class="card-content">
						<table id="logsTable" class="responsive-table centered striped highlight">
							<h6 class="flow-text indigo-text history-owner">Payout</h6>
							<thead>
								<th>Job</th>
								<th>Date</th>
								<th>Hours Worked</th>
								<th>Wage</th>
								<th>Status</th>
							</thead>
							<tbody>

							<?php if(!$wages->isEmpty()): ?>
								<?php $__currentLoopData = $wages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($wage->job->job); ?></td>
									<td><?php echo e($wage->date); ?></td>
									<td><?php echo e($wage->hours); ?></td>
									<td><strong>USD</strong> <?php echo e($wage->wage); ?></td>
									<td><?php echo e($wage->status->status); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<tr>
									<td class="info-text">No past payout.</td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
									<td class="info-text"> </td>
								</tr>
							<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('indiv_js'); ?>
	<script type="text/javascript">
		
		$(document).ready(function() {
			$('select').formSelect();
			$('.modal').modal();

			$('#editBtn').click(function() {
				$('#currentInfo').toggle();
				$('#editInfo').toggle();
			});
		});

		$('#clockIn').on('click', function() {
			var empID = $(this).val();
			var jobID = $('#todaysJob').val();
			var csrf = $('[name="csrf-token"]').attr('content');
			// alert(empID);
			// alert(csrf);
			// alert(jobID);

			$.post('/timesheet/clock-in/' + empID,
				{
					employee_id: empID,
					job_id: jobID,
					_token: csrf
				},
				function(data, status) {
					$('.clock-in').toggle();
					$('.clock-out').toggle();
					$('.todays-log').html(data);
					$('.todays-log').toggle();
				});
		});

		$('#clockOut').on('click', function() {
			var empID = $(this).val();
			var csrf = $('[name="csrf-token"]').attr('content');
			// alert(empID);
			// alert(csrf);

			$.post('/timesheet/clock-out/' + empID,
				{
					employee_id: empID,
					_token: csrf
				},
				function(data, status) {
					$('.clock-out').toggle();
					$('.todays-log').html(data);
				});
		});

		function formatTIN() {
			var inputTIN = document.getElementById("TIN");
			var newTIN = document.getElementById("TIN").value;
			// console.log(newTIN);
			newTIN = newTIN.replace(/[\W\D\s\._\-]+/g, '');

			var split = 3;
			var chunk = [];

			for (var i = 0, len = newTIN.length; i < len; i += split) {
				chunk.push(newTIN.substr(i, split));
			}

			var formattedTIN = chunk.join("-");
			// console.log(formattedTIN);
			inputTIN.value = formattedTIN;
		}

		function formatSSS() {
			var inputSSS = document.getElementById("SSS");
			var newSSS = document.getElementById("SSS").value;
			// console.log(newSSS);
			newSSS = newSSS.replace(/[\W\D\s\._\-]+/g, '');

			var split;
			var chunk = [];

			for (var i = 0, len = newSSS.length; i < len; i++) {
				switch (i) {
					case 0:
						split = 2;
						break;
					case 2:
						split = 7;
						break;
					case 9:
						split = 1;
						break;
					default:
						continue;
				}
				chunk.push(newSSS.substr(i, split));
			}

			var formattedSSS = chunk.join("-");
			// console.log(formattedSSS);
			inputSSS.value = formattedSSS;
		}

		function formatPagibig() {
			var inputPagibig = document.getElementById("Pagibig");
			var newPagibig = document.getElementById("Pagibig").value;
			// console.log(newPagibig);
			newPagibig = newPagibig.replace(/[\W\D\s\._\-]+/g, '');

			var split = 4;
			var chunk = [];

			for (var i = 0, len = newPagibig.length; i < len; i += split) {
				chunk.push(newPagibig.substr(i, split));
			}

			var formattedPagibig = chunk.join("-");
			// console.log(formattedPagibig);
			inputPagibig.value = formattedPagibig;
		}

	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>