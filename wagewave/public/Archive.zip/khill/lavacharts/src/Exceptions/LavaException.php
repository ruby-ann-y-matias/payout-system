<?php

namespace Khill\Lavacharts\Exceptions;

class LavaException extends \Exception
{
    //
}
